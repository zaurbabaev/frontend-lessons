export default {
  plugins: ["prettier-plugin-tailwindcss"],
};
